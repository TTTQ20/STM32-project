#ifndef __IWDG_H
#define __IWDG_H 			   

#include "stm32f10x.h"                  // Device header
#include "usart.h"  

void IWDG_Init(void);


#endif

